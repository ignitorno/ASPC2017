﻿using CrmEarlyBound;
using Microsoft.Xrm.Sdk;
using SGF.CRM.Plugins;
using System;
using ASPC.Skill.CRM.Plugins.bl;
using System.ServiceModel;

namespace ASPC.Skill.CRM.Plugins
{
    public class PostUserCrud : Plugin
    {
        public PostUserCrud(): base(typeof(PostUserCrud)) {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "systemuser", ExecutePostUserCrud));
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", "systemuser", ExecutePostUserCrud));

        }

        private void ExecutePostUserCrud(LocalPluginContext localContext)
        {
            try
            {
                if (localContext == null)
                {
                    throw new ArgumentNullException("localContext");
                }

                var service = localContext.OrganizationService;

                using (new CrmEntitiesContext(service))
                {
                    using (var exec = new AddRequiredSecurityRoles(localContext.OrganizationService, localContext.PluginExecutionContext, localContext.TracingService))
                    {
                        exec.Execute();
                    }
                }
            }
            catch (FaultException<InvalidPluginExecutionException> ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in the plug-in.", ex);
            }
        }
    }
}
