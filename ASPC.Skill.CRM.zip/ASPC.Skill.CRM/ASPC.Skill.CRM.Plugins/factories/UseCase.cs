﻿using CrmEarlyBound;
using Microsoft.Xrm.Sdk;
using System;

namespace ASPC.Skill.CRM.Plugins.factories
{
    public abstract class UseCase : IDisposable
    {
        private static string PreImageAlias { get { return "PreEntityImage"; } }
        private static string PostImageAlias { get { return "PostEntityImage"; } }

        protected TEntityType GetPreImage<TEntityType>() where TEntityType : Entity
        {
            var entity = (PluginContext.PreEntityImages != null && PluginContext.PreEntityImages.Contains(PreImageAlias)) ? PluginContext.PreEntityImages[PreImageAlias] : null;
            return entity == null ? null : entity.ToEntity<TEntityType>();
        }

        protected TEntityType GetPostImage<TEntityType>() where TEntityType : Entity
        {
            var entity = (PluginContext.PostEntityImages != null && PluginContext.PostEntityImages.Contains(PostImageAlias)) ? PluginContext.PostEntityImages[PostImageAlias] : null;
            return entity == null ? null : entity.ToEntity<TEntityType>();
        }

        protected TEntityType GetTarget<TEntityType>() where TEntityType : Entity
        {
            var entity = (Entity)PluginContext.InputParameters["Target"];
            return entity == null ? null : entity.ToEntity<TEntityType>();
        }

        protected CrmEntitiesContext CrmContext;
        private readonly IOrganizationService _service;
        protected readonly IPluginExecutionContext PluginContext;
        protected UseCase(IOrganizationService service, IPluginExecutionContext pluginContext)
        {
            _service = service;
            PluginContext = pluginContext;
        }

        public void Execute()
        {
            using (CrmContext = new CrmEntitiesContext(_service))
            {
                if (!IsToExecute()) return;
                try
                {
                    ExecuteCase();
                }
                catch (Exception exception)
                {
                    throw new InvalidPluginExecutionException(exception.Message, exception);
                }
                CrmContext.SaveChanges();
            }

        }
        protected void Update(Entity entity)
        {
            CrmContext.UpdateObject(entity);
        }
        protected void Attach(Entity entity)
        {
            CrmContext.Attach(entity);
        }
        protected abstract bool IsToExecute();
        protected abstract void ExecuteCase();

        public void Dispose()
        {
            CrmContext.Dispose();
        }
    }
}
