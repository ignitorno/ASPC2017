﻿using ASPC.Skill.CRM.Plugins.factories;
using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using CrmEarlyBound;

namespace ASPC.Skill.CRM.Plugins.bl
{
    class RandomizeAgentSkills : UseCase
    {
        private ITracingService tracingService;

        public RandomizeAgentSkills(IOrganizationService service, IPluginExecutionContext pluginContext) : base(service, pluginContext)
        {
        }

        public RandomizeAgentSkills(IOrganizationService service, IPluginExecutionContext pluginContext, ITracingService tracingService) : this(service, pluginContext)
        {
            this.tracingService = tracingService;
        }

        protected override void ExecuteCase()
        {
            var target = GetTarget<BookableResource>();

            var skills = (from s in CrmContext.CharacteristicSet
                          select s).ToList();

            var rnd = new Random();
            

            var ratingValues = (from r in CrmContext.RatingValueSet
                                select r).ToList();

            var previousSkill = new Characteristic();

            for (var i = 0; i < rnd.Next(1,5); i++)
            {
                
                var skill = skills[rnd.Next(0, skills.Count - 1)];

                while(skill == previousSkill)
                {
                    skill = skills[rnd.Next(0, skills.Count - 1)];
                }

                var ratingValue = ratingValues[rnd.Next(0, ratingValues.Count - 1)];

                try
                {
                    var agentSkill = new BookableResourceCharacteristic
                    {
                        Characteristic = skill.ToEntityReference(),
                        Resource = target.ToEntityReference(),
                        RatingValue = ratingValue.ToEntityReference(),
                    };


                    CrmContext.AddObject(agentSkill);

                    previousSkill = skill;
                }
                catch(InvalidPluginExecutionException ipee)
                {
                    throw ipee;
                }
            }
            CrmContext.SaveChanges();
        }

        protected override bool IsToExecute()
        {
            return true;
        }
    }
}
