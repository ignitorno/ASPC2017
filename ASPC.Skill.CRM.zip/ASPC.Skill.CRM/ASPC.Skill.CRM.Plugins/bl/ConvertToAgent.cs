﻿using ASPC.Skill.CRM.Plugins.factories;
using System.Linq;
using Microsoft.Xrm.Sdk;
using CrmEarlyBound;

namespace ASPC.Skill.CRM.Plugins.bl
{
    class ConvertToAgent : UseCase
    {
        private IOrganizationService organizationService;
        private IPluginExecutionContext pluginExecutionContext;
        private ITracingService tracingService;

        public ConvertToAgent(IOrganizationService organizationService, IPluginExecutionContext pluginExecutionContext, ITracingService tracingService) : this(organizationService, pluginExecutionContext)
        {
            this.organizationService = organizationService;
            this.pluginExecutionContext = pluginExecutionContext;
            this.tracingService = tracingService;
        }

        protected ConvertToAgent(IOrganizationService service, IPluginExecutionContext pluginContext) : base(service, pluginContext)
        {
        }

        protected override void ExecuteCase()
        {
            var target = GetTarget<Contact>();

            var agentavatarImg = (from aa in CrmContext.skill_agentavatarSet
                               where aa.Id == target.skill_agentid.Id
                               select                                
                                   aa.EntityImage
                               ).FirstOrDefault();
            //target.EntityImage = agentavatarImg;

            var c = new Contact
            {
                Id = target.Id,
                EntityImage = agentavatarImg
            };

            CrmContext.Attach(c);
            CrmContext.UpdateObject(c);
            CrmContext.SaveChanges();
        }

        protected override bool IsToExecute()
        {
            var target = GetTarget<Contact>();
            return target.skill_agentid != null;            
        }
    }
}
