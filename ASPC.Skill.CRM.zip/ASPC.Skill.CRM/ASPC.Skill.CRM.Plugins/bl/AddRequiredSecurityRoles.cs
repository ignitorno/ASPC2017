﻿using ASPC.Skill.CRM.Plugins.factories;
using System.Linq;
using Microsoft.Xrm.Sdk;
using CrmEarlyBound;

namespace ASPC.Skill.CRM.Plugins.bl
{
    class AddRequiredSecurityRoles : UseCase
    {
        private ITracingService tracingService;
        private IOrganizationService service;

        public AddRequiredSecurityRoles(IOrganizationService service, IPluginExecutionContext pluginContext) : base(service, pluginContext)
        {
        }

        public AddRequiredSecurityRoles(IOrganizationService service, IPluginExecutionContext pluginContext, ITracingService tracingService) : this(service, pluginContext)
        {
            this.tracingService = tracingService;
            this.service = service;
        }

        protected override void ExecuteCase()
        {
            var postEntity = GetPostImage<SystemUser>();
            
            var user = postEntity.SystemUserId;
            var bu = postEntity.BusinessUnitId;
            var sg = postEntity.skill_securitygroupid;
            if (bu == null && sg == null) return;

            var roles = (from r in CrmContext.skill_roleSet
                         where r.skill_securitygroupid == sg
                         select new
                         {
                             r.skill_name,
                         });

            CrmContext.Dispose();

            foreach(var role in roles)
            {
                var secRole = (from r in CrmContext.RoleSet
                               where r.BusinessUnitId == bu
                               where r.Name == role.skill_name
                               select r).FirstOrDefault();

                if (secRole == null) continue;

                service.Associate(SystemUser.EntityLogicalName,user.Value,new Relationship("systemuserroles_association"),
                        new EntityReferenceCollection() { new EntityReference(Role.EntityLogicalName, secRole.Id) });
            }
        }

        protected override bool IsToExecute()
        {
            var target = GetTarget<SystemUser>();
            return target.BusinessUnitId != null || target.skill_securitygroupid != null;
        }
    }
}
