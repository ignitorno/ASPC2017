﻿using ASPC.Skill.CRM.Plugins.bl;
using CrmEarlyBound;
using Microsoft.Xrm.Sdk;
using SGF.CRM.Plugins;
using System;
using System.ServiceModel;

namespace ASPC.Skill.CRM.Plugins
{
    public class PostContactCrud : Plugin
    {
        public PostContactCrud(): base(typeof(PostContactCrud))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "contact", ExecutePostContactCrud));
        }


        protected void ExecutePostContactCrud(LocalPluginContext localContext)
        {
            try
            {
                if (localContext == null)
                {
                    throw new ArgumentNullException("localContext");
                }

                var service = localContext.OrganizationService;

                using (new CrmEntitiesContext(service))
                {
                    using (var exec = new ConvertToAgent(localContext.OrganizationService, localContext.PluginExecutionContext, localContext.TracingService)) 
                    {
                        exec.Execute();
                    }
                }
            }
            catch (FaultException<InvalidPluginExecutionException> ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in the plug-in.", ex);
            }
        }


    }
}
