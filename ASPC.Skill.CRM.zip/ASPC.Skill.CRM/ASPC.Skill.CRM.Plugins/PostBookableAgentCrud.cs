﻿using ASPC.Skill.CRM.Plugins.bl;
using CrmEarlyBound;
using Microsoft.Xrm.Sdk;
using SGF.CRM.Plugins;
using System;
using System.ServiceModel;

namespace ASPC.Skill.CRM.Plugins
{
    public class PostBookableAgentCrud : Plugin
    {
        public PostBookableAgentCrud(): base(typeof(PostContactCrud))
        {
            RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Create", CrmEarlyBound.BookableResource.EntityLogicalName, ExecutePostBookableAgentCrud));
        }


        protected void ExecutePostBookableAgentCrud(LocalPluginContext localContext)
        {
            try
            {
                if (localContext == null)
                {
                    throw new ArgumentNullException("localContext");
                }

                var service = localContext.OrganizationService;

                using (new CrmEntitiesContext(service))
                {
                    using (var exec = new RandomizeAgentSkills(localContext.OrganizationService, localContext.PluginExecutionContext, localContext.TracingService))
                    {
                        exec.Execute();
                    }
                }
            }
            catch (FaultException<InvalidPluginExecutionException> ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in the plug-in.", ex);
            }
        }
    }
}
